﻿namespace KClick
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnAdd = new System.Windows.Forms.Button();
            this.pnlControl = new System.Windows.Forms.Panel();
            this.btnGetPosition2 = new System.Windows.Forms.Button();
            this.txtY2 = new System.Windows.Forms.TextBox();
            this.lblY2 = new System.Windows.Forms.Label();
            this.txtX2 = new System.Windows.Forms.TextBox();
            this.lblX2 = new System.Windows.Forms.Label();
            this.txtColor2 = new System.Windows.Forms.TextBox();
            this.lblColor2 = new System.Windows.Forms.Label();
            this.txtColor1 = new System.Windows.Forms.TextBox();
            this.lblColor1 = new System.Windows.Forms.Label();
            this.btnGetPosition = new System.Windows.Forms.Button();
            this.btnClearScripts = new System.Windows.Forms.Button();
            this.txtDelay = new System.Windows.Forms.TextBox();
            this.lblDelay = new System.Windows.Forms.Label();
            this.txtYPos = new System.Windows.Forms.TextBox();
            this.lblYPos = new System.Windows.Forms.Label();
            this.txtXPos = new System.Windows.Forms.TextBox();
            this.lblXPos = new System.Windows.Forms.Label();
            this.btnFindControl = new System.Windows.Forms.Button();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblName = new System.Windows.Forms.Label();
            this.txtClass = new System.Windows.Forms.TextBox();
            this.lblClass = new System.Windows.Forms.Label();
            this.btnStop = new System.Windows.Forms.Button();
            this.btnRun = new System.Windows.Forms.Button();
            this.pnlGrid = new System.Windows.Forms.Panel();
            this.lsvScripts = new System.Windows.Forms.ListView();
            this.colNo = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colMouseKey = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colDelay = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.btnDelete = new System.Windows.Forms.ToolStripMenuItem();
            this.btnExport = new System.Windows.Forms.Button();
            this.btnImport = new System.Windows.Forms.Button();
            this.colInfo1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colInfo2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panel1 = new System.Windows.Forms.Panel();
            this.rdoInfinity = new System.Windows.Forms.RadioButton();
            this.rdoLimit = new System.Windows.Forms.RadioButton();
            this.txtLoopTime = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnFixControl = new System.Windows.Forms.Button();
            this.btnApplyDelay = new System.Windows.Forms.Button();
            this.grbIgnore = new System.Windows.Forms.GroupBox();
            this.btnGetPositionIgnored1 = new System.Windows.Forms.Button();
            this.txtYIgnored1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtXIgnored1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtColorIgnored1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.pnlControl.SuspendLayout();
            this.pnlGrid.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.grbIgnore.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(15, 294);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(74, 33);
            this.btnAdd.TabIndex = 0;
            this.btnAdd.Text = "Add Script";
            this.btnAdd.UseVisualStyleBackColor = true;
            // 
            // pnlControl
            // 
            this.pnlControl.Controls.Add(this.grbIgnore);
            this.pnlControl.Controls.Add(this.btnApplyDelay);
            this.pnlControl.Controls.Add(this.btnFixControl);
            this.pnlControl.Controls.Add(this.panel1);
            this.pnlControl.Controls.Add(this.btnImport);
            this.pnlControl.Controls.Add(this.btnExport);
            this.pnlControl.Controls.Add(this.btnGetPosition2);
            this.pnlControl.Controls.Add(this.txtY2);
            this.pnlControl.Controls.Add(this.lblY2);
            this.pnlControl.Controls.Add(this.txtX2);
            this.pnlControl.Controls.Add(this.lblX2);
            this.pnlControl.Controls.Add(this.txtColor2);
            this.pnlControl.Controls.Add(this.lblColor2);
            this.pnlControl.Controls.Add(this.txtColor1);
            this.pnlControl.Controls.Add(this.lblColor1);
            this.pnlControl.Controls.Add(this.btnGetPosition);
            this.pnlControl.Controls.Add(this.btnClearScripts);
            this.pnlControl.Controls.Add(this.txtDelay);
            this.pnlControl.Controls.Add(this.lblDelay);
            this.pnlControl.Controls.Add(this.txtYPos);
            this.pnlControl.Controls.Add(this.lblYPos);
            this.pnlControl.Controls.Add(this.txtXPos);
            this.pnlControl.Controls.Add(this.lblXPos);
            this.pnlControl.Controls.Add(this.btnFindControl);
            this.pnlControl.Controls.Add(this.txtName);
            this.pnlControl.Controls.Add(this.lblName);
            this.pnlControl.Controls.Add(this.txtClass);
            this.pnlControl.Controls.Add(this.lblClass);
            this.pnlControl.Controls.Add(this.btnStop);
            this.pnlControl.Controls.Add(this.btnRun);
            this.pnlControl.Controls.Add(this.btnAdd);
            this.pnlControl.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlControl.Location = new System.Drawing.Point(0, 0);
            this.pnlControl.Name = "pnlControl";
            this.pnlControl.Size = new System.Drawing.Size(523, 339);
            this.pnlControl.TabIndex = 1;
            // 
            // btnGetPosition2
            // 
            this.btnGetPosition2.Location = new System.Drawing.Point(455, 94);
            this.btnGetPosition2.Name = "btnGetPosition2";
            this.btnGetPosition2.Size = new System.Drawing.Size(56, 72);
            this.btnGetPosition2.TabIndex = 12;
            this.btnGetPosition2.Text = "Get Position";
            this.btnGetPosition2.UseVisualStyleBackColor = true;
            // 
            // txtY2
            // 
            this.txtY2.Location = new System.Drawing.Point(349, 120);
            this.txtY2.Name = "txtY2";
            this.txtY2.Size = new System.Drawing.Size(100, 20);
            this.txtY2.TabIndex = 8;
            // 
            // lblY2
            // 
            this.lblY2.AutoSize = true;
            this.lblY2.Location = new System.Drawing.Point(275, 124);
            this.lblY2.Name = "lblY2";
            this.lblY2.Size = new System.Drawing.Size(68, 13);
            this.lblY2.TabIndex = 23;
            this.lblY2.Text = "Y2 (Optional)";
            // 
            // txtX2
            // 
            this.txtX2.Location = new System.Drawing.Point(349, 94);
            this.txtX2.Name = "txtX2";
            this.txtX2.Size = new System.Drawing.Size(100, 20);
            this.txtX2.TabIndex = 7;
            // 
            // lblX2
            // 
            this.lblX2.AutoSize = true;
            this.lblX2.Location = new System.Drawing.Point(275, 97);
            this.lblX2.Name = "lblX2";
            this.lblX2.Size = new System.Drawing.Size(68, 13);
            this.lblX2.TabIndex = 21;
            this.lblX2.Text = "X2 (Optional)";
            // 
            // txtColor2
            // 
            this.txtColor2.Location = new System.Drawing.Point(350, 146);
            this.txtColor2.Name = "txtColor2";
            this.txtColor2.Size = new System.Drawing.Size(100, 20);
            this.txtColor2.TabIndex = 9;
            // 
            // lblColor2
            // 
            this.lblColor2.AutoSize = true;
            this.lblColor2.Location = new System.Drawing.Point(262, 149);
            this.lblColor2.Name = "lblColor2";
            this.lblColor2.Size = new System.Drawing.Size(88, 13);
            this.lblColor2.TabIndex = 19;
            this.lblColor2.Text = "Color 2 (Optional)";
            // 
            // txtColor1
            // 
            this.txtColor1.Location = new System.Drawing.Point(96, 146);
            this.txtColor1.Name = "txtColor1";
            this.txtColor1.Size = new System.Drawing.Size(100, 20);
            this.txtColor1.TabIndex = 6;
            // 
            // lblColor1
            // 
            this.lblColor1.AutoSize = true;
            this.lblColor1.Location = new System.Drawing.Point(17, 147);
            this.lblColor1.Name = "lblColor1";
            this.lblColor1.Size = new System.Drawing.Size(63, 13);
            this.lblColor1.TabIndex = 17;
            this.lblColor1.Text = "Color (Main)";
            // 
            // btnGetPosition
            // 
            this.btnGetPosition.Location = new System.Drawing.Point(198, 95);
            this.btnGetPosition.Name = "btnGetPosition";
            this.btnGetPosition.Size = new System.Drawing.Size(55, 72);
            this.btnGetPosition.TabIndex = 11;
            this.btnGetPosition.Text = "Get Position";
            this.btnGetPosition.UseVisualStyleBackColor = true;
            // 
            // btnClearScripts
            // 
            this.btnClearScripts.Location = new System.Drawing.Point(435, 294);
            this.btnClearScripts.Name = "btnClearScripts";
            this.btnClearScripts.Size = new System.Drawing.Size(76, 33);
            this.btnClearScripts.TabIndex = 15;
            this.btnClearScripts.Text = "Clear Scripts";
            this.btnClearScripts.UseVisualStyleBackColor = true;
            // 
            // txtDelay
            // 
            this.txtDelay.Location = new System.Drawing.Point(96, 67);
            this.txtDelay.Name = "txtDelay";
            this.txtDelay.Size = new System.Drawing.Size(100, 20);
            this.txtDelay.TabIndex = 3;
            this.txtDelay.Text = "500";
            // 
            // lblDelay
            // 
            this.lblDelay.AutoSize = true;
            this.lblDelay.Location = new System.Drawing.Point(16, 68);
            this.lblDelay.Name = "lblDelay";
            this.lblDelay.Size = new System.Drawing.Size(34, 13);
            this.lblDelay.TabIndex = 13;
            this.lblDelay.Text = "Delay";
            // 
            // txtYPos
            // 
            this.txtYPos.Location = new System.Drawing.Point(95, 120);
            this.txtYPos.Name = "txtYPos";
            this.txtYPos.Size = new System.Drawing.Size(100, 20);
            this.txtYPos.TabIndex = 5;
            // 
            // lblYPos
            // 
            this.lblYPos.AutoSize = true;
            this.lblYPos.Location = new System.Drawing.Point(16, 121);
            this.lblYPos.Name = "lblYPos";
            this.lblYPos.Size = new System.Drawing.Size(46, 13);
            this.lblYPos.TabIndex = 11;
            this.lblYPos.Text = "Y (Main)";
            // 
            // txtXPos
            // 
            this.txtXPos.Location = new System.Drawing.Point(95, 94);
            this.txtXPos.Name = "txtXPos";
            this.txtXPos.Size = new System.Drawing.Size(100, 20);
            this.txtXPos.TabIndex = 4;
            // 
            // lblXPos
            // 
            this.lblXPos.AutoSize = true;
            this.lblXPos.Location = new System.Drawing.Point(16, 95);
            this.lblXPos.Name = "lblXPos";
            this.lblXPos.Size = new System.Drawing.Size(46, 13);
            this.lblXPos.TabIndex = 9;
            this.lblXPos.Text = "X (Main)";
            // 
            // btnFindControl
            // 
            this.btnFindControl.Location = new System.Drawing.Point(198, 13);
            this.btnFindControl.Name = "btnFindControl";
            this.btnFindControl.Size = new System.Drawing.Size(55, 42);
            this.btnFindControl.TabIndex = 10;
            this.btnFindControl.Text = "Take Control";
            this.btnFindControl.UseVisualStyleBackColor = true;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(96, 35);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(100, 20);
            this.txtName.TabIndex = 2;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(17, 33);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(35, 13);
            this.lblName.TabIndex = 5;
            this.lblName.Text = "Name";
            // 
            // txtClass
            // 
            this.txtClass.Location = new System.Drawing.Point(96, 12);
            this.txtClass.Name = "txtClass";
            this.txtClass.Size = new System.Drawing.Size(100, 20);
            this.txtClass.TabIndex = 1;
            // 
            // lblClass
            // 
            this.lblClass.AutoSize = true;
            this.lblClass.Location = new System.Drawing.Point(18, 15);
            this.lblClass.Name = "lblClass";
            this.lblClass.Size = new System.Drawing.Size(32, 13);
            this.lblClass.TabIndex = 3;
            this.lblClass.Text = "Class";
            // 
            // btnStop
            // 
            this.btnStop.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnStop.Enabled = false;
            this.btnStop.Location = new System.Drawing.Point(175, 295);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(75, 34);
            this.btnStop.TabIndex = 2;
            this.btnStop.Text = "Stop (Alt-S)";
            this.btnStop.UseVisualStyleBackColor = true;
            // 
            // btnRun
            // 
            this.btnRun.Location = new System.Drawing.Point(95, 295);
            this.btnRun.Name = "btnRun";
            this.btnRun.Size = new System.Drawing.Size(74, 34);
            this.btnRun.TabIndex = 1;
            this.btnRun.Text = "Run";
            this.btnRun.UseVisualStyleBackColor = true;
            // 
            // pnlGrid
            // 
            this.pnlGrid.Controls.Add(this.lsvScripts);
            this.pnlGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlGrid.Location = new System.Drawing.Point(0, 339);
            this.pnlGrid.Name = "pnlGrid";
            this.pnlGrid.Size = new System.Drawing.Size(523, 216);
            this.pnlGrid.TabIndex = 2;
            // 
            // lsvScripts
            // 
            this.lsvScripts.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colNo,
            this.colMouseKey,
            this.colDelay,
            this.colInfo1,
            this.colInfo2});
            this.lsvScripts.ContextMenuStrip = this.contextMenuStrip1;
            this.lsvScripts.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lsvScripts.FullRowSelect = true;
            this.lsvScripts.GridLines = true;
            this.lsvScripts.Location = new System.Drawing.Point(0, 0);
            this.lsvScripts.Name = "lsvScripts";
            this.lsvScripts.Size = new System.Drawing.Size(523, 216);
            this.lsvScripts.TabIndex = 0;
            this.lsvScripts.UseCompatibleStateImageBehavior = false;
            this.lsvScripts.View = System.Windows.Forms.View.Details;
            // 
            // colNo
            // 
            this.colNo.Text = "No.";
            // 
            // colMouseKey
            // 
            this.colMouseKey.Text = "Mouse Key";
            // 
            // colDelay
            // 
            this.colDelay.Text = "Delay";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnDelete});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(108, 26);
            // 
            // btnDelete
            // 
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(107, 22);
            this.btnDelete.Text = "Delete";
            // 
            // btnExport
            // 
            this.btnExport.Location = new System.Drawing.Point(354, 294);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(74, 34);
            this.btnExport.TabIndex = 28;
            this.btnExport.Text = "Save Script";
            this.btnExport.UseVisualStyleBackColor = true;
            // 
            // btnImport
            // 
            this.btnImport.Location = new System.Drawing.Point(274, 294);
            this.btnImport.Name = "btnImport";
            this.btnImport.Size = new System.Drawing.Size(74, 34);
            this.btnImport.TabIndex = 29;
            this.btnImport.Text = "Load Script";
            this.btnImport.UseVisualStyleBackColor = true;
            // 
            // colInfo1
            // 
            this.colInfo1.Text = "Info 1";
            this.colInfo1.Width = 150;
            // 
            // colInfo2
            // 
            this.colInfo2.Text = "Info 2";
            this.colInfo2.Width = 150;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.txtLoopTime);
            this.panel1.Controls.Add(this.rdoLimit);
            this.panel1.Controls.Add(this.rdoInfinity);
            this.panel1.Location = new System.Drawing.Point(320, 13);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(191, 72);
            this.panel1.TabIndex = 30;
            // 
            // rdoInfinity
            // 
            this.rdoInfinity.AutoSize = true;
            this.rdoInfinity.Checked = true;
            this.rdoInfinity.Location = new System.Drawing.Point(17, 13);
            this.rdoInfinity.Name = "rdoInfinity";
            this.rdoInfinity.Size = new System.Drawing.Size(55, 17);
            this.rdoInfinity.TabIndex = 0;
            this.rdoInfinity.TabStop = true;
            this.rdoInfinity.Text = "Infinity";
            this.rdoInfinity.UseVisualStyleBackColor = true;
            // 
            // rdoLimit
            // 
            this.rdoLimit.AutoSize = true;
            this.rdoLimit.Location = new System.Drawing.Point(17, 35);
            this.rdoLimit.Name = "rdoLimit";
            this.rdoLimit.Size = new System.Drawing.Size(46, 17);
            this.rdoLimit.TabIndex = 1;
            this.rdoLimit.Text = "Limit";
            this.rdoLimit.UseVisualStyleBackColor = true;
            // 
            // txtLoopTime
            // 
            this.txtLoopTime.Enabled = false;
            this.txtLoopTime.Location = new System.Drawing.Point(89, 35);
            this.txtLoopTime.Name = "txtLoopTime";
            this.txtLoopTime.Size = new System.Drawing.Size(41, 20);
            this.txtLoopTime.TabIndex = 2;
            this.txtLoopTime.Text = "1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(136, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "time(s)";
            // 
            // btnFixControl
            // 
            this.btnFixControl.Location = new System.Drawing.Point(259, 13);
            this.btnFixControl.Name = "btnFixControl";
            this.btnFixControl.Size = new System.Drawing.Size(55, 42);
            this.btnFixControl.TabIndex = 31;
            this.btnFixControl.Text = "Fix Size Control";
            this.btnFixControl.UseVisualStyleBackColor = true;
            // 
            // btnApplyDelay
            // 
            this.btnApplyDelay.Location = new System.Drawing.Point(198, 66);
            this.btnApplyDelay.Name = "btnApplyDelay";
            this.btnApplyDelay.Size = new System.Drawing.Size(54, 23);
            this.btnApplyDelay.TabIndex = 32;
            this.btnApplyDelay.Text = "Apply";
            this.btnApplyDelay.UseVisualStyleBackColor = true;
            // 
            // grbIgnore
            // 
            this.grbIgnore.Controls.Add(this.btnGetPositionIgnored1);
            this.grbIgnore.Controls.Add(this.txtYIgnored1);
            this.grbIgnore.Controls.Add(this.label2);
            this.grbIgnore.Controls.Add(this.txtXIgnored1);
            this.grbIgnore.Controls.Add(this.label3);
            this.grbIgnore.Controls.Add(this.txtColorIgnored1);
            this.grbIgnore.Controls.Add(this.label4);
            this.grbIgnore.Cursor = System.Windows.Forms.Cursors.Default;
            this.grbIgnore.Location = new System.Drawing.Point(13, 173);
            this.grbIgnore.Name = "grbIgnore";
            this.grbIgnore.Size = new System.Drawing.Size(498, 115);
            this.grbIgnore.TabIndex = 33;
            this.grbIgnore.TabStop = false;
            this.grbIgnore.Text = "Successful Color (If matching this click point, mouse clicking will be ignored. S" +
    "hould use it only when you have the repeated actions)";
            // 
            // btnGetPositionIgnored1
            // 
            this.btnGetPositionIgnored1.Location = new System.Drawing.Point(185, 35);
            this.btnGetPositionIgnored1.Name = "btnGetPositionIgnored1";
            this.btnGetPositionIgnored1.Size = new System.Drawing.Size(56, 72);
            this.btnGetPositionIgnored1.TabIndex = 27;
            this.btnGetPositionIgnored1.Text = "Get Position";
            this.btnGetPositionIgnored1.UseVisualStyleBackColor = true;
            // 
            // txtYIgnored1
            // 
            this.txtYIgnored1.Location = new System.Drawing.Point(83, 61);
            this.txtYIgnored1.Name = "txtYIgnored1";
            this.txtYIgnored1.Size = new System.Drawing.Size(100, 20);
            this.txtYIgnored1.TabIndex = 25;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(5, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 13);
            this.label2.TabIndex = 30;
            this.label2.Text = "Y (Optional)";
            // 
            // txtXIgnored1
            // 
            this.txtXIgnored1.Location = new System.Drawing.Point(83, 35);
            this.txtXIgnored1.Name = "txtXIgnored1";
            this.txtXIgnored1.Size = new System.Drawing.Size(100, 20);
            this.txtXIgnored1.TabIndex = 24;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(5, 35);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 13);
            this.label3.TabIndex = 29;
            this.label3.Text = "X (Optional)";
            // 
            // txtColorIgnored1
            // 
            this.txtColorIgnored1.Location = new System.Drawing.Point(83, 87);
            this.txtColorIgnored1.Name = "txtColorIgnored1";
            this.txtColorIgnored1.Size = new System.Drawing.Size(100, 20);
            this.txtColorIgnored1.TabIndex = 26;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 90);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 13);
            this.label4.TabIndex = 28;
            this.label4.Text = "Color (Optional)";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnStop;
            this.ClientSize = new System.Drawing.Size(523, 555);
            this.Controls.Add(this.pnlGrid);
            this.Controls.Add(this.pnlControl);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MainForm";
            this.ShowIcon = false;
            this.Text = "KClick";
            this.pnlControl.ResumeLayout(false);
            this.pnlControl.PerformLayout();
            this.pnlGrid.ResumeLayout(false);
            this.contextMenuStrip1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.grbIgnore.ResumeLayout(false);
            this.grbIgnore.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Panel pnlControl;
        private System.Windows.Forms.Panel pnlGrid;
        private System.Windows.Forms.ListView lsvScripts;
        private System.Windows.Forms.ColumnHeader colNo;
        private System.Windows.Forms.ColumnHeader colMouseKey;
        private System.Windows.Forms.Button btnFindControl;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TextBox txtClass;
        private System.Windows.Forms.Label lblClass;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Button btnRun;
        private System.Windows.Forms.TextBox txtYPos;
        private System.Windows.Forms.Label lblYPos;
        private System.Windows.Forms.TextBox txtXPos;
        private System.Windows.Forms.Label lblXPos;
        private System.Windows.Forms.TextBox txtDelay;
        private System.Windows.Forms.Label lblDelay;
        private System.Windows.Forms.ColumnHeader colDelay;
        private System.Windows.Forms.Button btnClearScripts;
        private System.Windows.Forms.Button btnGetPosition;
        private System.Windows.Forms.TextBox txtColor1;
        private System.Windows.Forms.Label lblColor1;
        private System.Windows.Forms.TextBox txtColor2;
        private System.Windows.Forms.Label lblColor2;
        private System.Windows.Forms.TextBox txtY2;
        private System.Windows.Forms.Label lblY2;
        private System.Windows.Forms.TextBox txtX2;
        private System.Windows.Forms.Label lblX2;
        private System.Windows.Forms.Button btnGetPosition2;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem btnDelete;
        private System.Windows.Forms.Button btnExport;
        private System.Windows.Forms.Button btnImport;
        private System.Windows.Forms.ColumnHeader colInfo1;
        private System.Windows.Forms.ColumnHeader colInfo2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton rdoInfinity;
        private System.Windows.Forms.RadioButton rdoLimit;
        private System.Windows.Forms.TextBox txtLoopTime;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnFixControl;
        private System.Windows.Forms.Button btnApplyDelay;
        private System.Windows.Forms.GroupBox grbIgnore;
        private System.Windows.Forms.Button btnGetPositionIgnored1;
        private System.Windows.Forms.TextBox txtYIgnored1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtXIgnored1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtColorIgnored1;
        private System.Windows.Forms.Label label4;
    }
}

